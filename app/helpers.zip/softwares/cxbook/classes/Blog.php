<?php namespace classes;   

    class Blog extends \AutoProps
    {
        
        
    }