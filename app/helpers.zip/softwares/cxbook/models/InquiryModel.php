<?php

  class InquiryModel extends Model
  {
    public $table = 'inquiries';
  }
