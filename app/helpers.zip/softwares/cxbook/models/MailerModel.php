<?php

  class MailerModel extends Model
  {
    public $table = 'cb_mailer_messages';
  }
