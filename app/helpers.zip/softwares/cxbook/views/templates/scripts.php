
<script src="<?php echo _path_vendor('cork/assets/js/libs/jquery-3.1.1.min.js')?>"></script>
<script src="<?php echo _path_vendor('cork/bootstrap/js/popper.min.js')?>"></script>
<script src="<?php echo _path_vendor('cork/bootstrap/js/bootstrap.min.js')?>"></script>
<script src="<?php echo _path_vendor('cork/plugins/perfect-scrollbar/perfect-scrollbar.min.js')?>"></script>
<script src="<?php echo _path_vendor('cork/assets/js/app.js')?>"></script>
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script src="<?php echo _path_vendor('cork/assets/js/custom.js')?>"></script>
