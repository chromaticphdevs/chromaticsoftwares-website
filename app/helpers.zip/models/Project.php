<?php 
  class ProjectModel extends Model
  {
    public function all()
    {
      return [
      ];
    }
  }
