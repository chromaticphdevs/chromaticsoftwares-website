<nav class="navbar header-nav navbar-expand-lg">
<?php
  $request = $_SERVER['REQUEST_URI'] ?? '';

  $request = !empty($request) ? explode('/',$request) : [];

  $active  = !empty($request[1]) ? trim(strtolower($request[1])) : 'home';
?>
<div class="container">
    <a class="navbar-brand" href="/"><img src="<?php echo base_url('tmp/images/logo.png')?>" alt="image"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarApp"
    aria-controls="navbarApp" aria-expanded="false" aria-label="Toggle navigation">
      <span></span>
      <span></span>
      <span></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarApp">
      <ul class="navbar-nav">
        <li>
          <a href="/" class="nav-link <?php echo $active == 'home' ? 'active' : '' ?>">Home</a>
        </li>
        <li>
          <a href="/projects" class="nav-link <?php echo $active == 'projects' ? 'active' : '' ?>">Projects</a>
        </li>
        <li>
          <a href="/about" class="nav-link <?php echo $active == 'about' ? 'active' : '' ?>">About</a>
        </li>
        <li>
          <a href="/blogs" class="nav-link <?php echo $active == 'blogs' ? 'active' : '' ?>">Blog</a>
        </li>
        <li>
          <a href="/contact" class="nav-link <?php echo $active == 'contact' ? 'active' : '' ?>">Contact</a>
        </li>
    </ul>
    </div>
</div>
</nav>
