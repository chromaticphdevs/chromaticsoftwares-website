<!-- ALL JS FILES -->
<script src="<?php echo base_url('tmp/js/all.js')?>"></script>
<!-- ALL PLUGINS -->
<script src="<?php echo base_url('tmp/js/main.js')?>"></script>
<script src="<?php echo base_url('tmp/js/custom.js')?>"></script>
<script src="<?php echo base_url('tmp/js/swiper.min.js')?>"></script>

<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-172982658-1');
</script>
