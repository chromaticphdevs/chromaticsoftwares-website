  <?php view('templates/headers')?>
    <link rel="stylesheet" href="<?php echo base_url('css/pages/projects.css')?>">

    <style media="screen">
    #banner .head-line {
      color: #fff;
      text-align: left;
      padding-top: 90px;
    }

    #banner .head-line .overlay
    {
      display: block;
      background: rgba(0,0,0 , .5);
      min-width:350px;
      max-width: 1000px;
      padding: 20px 0px;
      margin:0px auto;
    }

    .story {
      line-height: 200%;
    }
    .action-widget {
      background: #10375c;
      color:#fff;
      padding: 20px;
      border-radius: 20px;
      margin:30px 0px;
    }
    </style>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body class="app_version" data-spy="scroll" data-target="#navbarApp" data-offset="98">

    <!-- LOADER -->
    <!-- <div id="preloader">
        <img class="preloader" src="images/loaders/loader-app.gif" alt="">
    </div> -->
    <!-- end loader -->
    <!-- END LOADER -->
    <header class="header header_style_01">
      <?php echo view('templates/navigation')?>
    </header>

    <div id="header">
      <div id="banner">
        <div class="head-line">
          <div class="overlay">
            <h3><?php echo strtoupper($title)?></h3>

            <p class="sub-text">
              We are to build software solutions that will empower Businesses, our goal
              Is to help start-ups and growing business to leverage the power of technology.
            </p>
          </div>
        </div>
      </div>
      <!-- END OF BANNER -->
    </div>


  <div class="container story">
    <div class="col-md-9 mx-auto">
      <div class="text-center">
        <h1 class="content-spacing"> <strong>Story</strong> </h1>
        <p>Chromatic is about building something usefull , something that matters <br/>
          its about something that you care about</p>

          <img src="<?php echo _path_asset('logo.png')?>" alt="">
      </div>

      <div class="story-p text-left">
        <p>
          Chromatic all started back when I was in college, a friend of mine asked me to build their project for them.
          My excitement burst as he describes me the project,
          the project is Online point of sale with inventory system.

          <img src="<?php echo _path_asset('blog/pic_2.jpg')?>" width="100%">
        </p>

        <p>
          I was so happy and excited I want to start building It right away.
          I naively accepted the project despite the lack of knowledge on the project ,
          a lot of things happened while on the development phase after a month and a half we managed to
          finished the project and we are far early on the deadline , I failed most of my subjects but I felt accomplished.

          <img src="<?php echo _path_asset('blog/pic_1.jpg')?>" width="100%" alt="">
        </p>

        <p>
          After months of months of doing software for students I felt empty as the system get disposed after passing their thesis,
          its like all of the hard works , passion and enthusiasm  of building the project is being thrown away in the trash it hits me ¸
          then realized why not make software’s for companies where people will use it make their work a lot more easier.
        </p>
        <p>
          We start looking for companies that we can work with . <br/>
          We got our very first project as chromatic way back 2019 on <a href="https://kondoko.com" taget="_blank"><strong>Kondoko a property management company</strong></a> .
          I will be forever grateful to them for giving us a chance to prove our skills, determination and love of work ,
          thank you very much.
        </p>

        <p>
          Chromatic will continue to grow as a software development company helping companies to have their
          custom-built software’s to fulfil their specific business requirements.
        </p>

        <div class="text-center action-widget">
          <h4 style="color:#fff"> Let the next billion dollar software company make solutions for you</h4>
          <a href="/Contact" class="btn btn-primary">Hire us</a>
        </div>
      </div>
    </div>

  </div>


  <?php echo view('templates/footer')?>

    <a href="#home" data-scroll class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>
    <?php echo view('templates/scripts')?>
</body>
</html>
