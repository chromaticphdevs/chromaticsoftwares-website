<?php namespace App\Controllers;

class Sample extends BaseController
{
	public function index()
	{
    echo 'Hello good morning';
	}

	//--------------------------------------------------------------------

}
