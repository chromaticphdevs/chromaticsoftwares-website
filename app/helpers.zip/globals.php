<?php use Globals\Visitor;

load(
  [
    'Visitor'
  ],
  GLOBALS
);


$visitor = new Visitor();
