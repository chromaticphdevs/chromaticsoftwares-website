<?php 	
	
	require_once MODELS.DS.'KeysInventoryModel.php';

	class Inventories
	{
		public function __construct()
		{
			// $this->model = new KeysInventoryModel();
		}

		public function get()
		{
			// echo $_GET['url'];
		}
	}