<?php   namespace core;


    class SoftwareLoader 
    {

        public function __construct($app)
        {
            //chheck if url[0] is an app

            //if app then load application
        }
    }