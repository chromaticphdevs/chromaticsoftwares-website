<?php   

    class Config
    {

        public static function get($args)
        {
            
        }
    }